﻿![alt text](https://i.postimg.cc/fbrKNFwy/logo-u-sql-big.png) 

U-SQL project
=============
In order to run the example, you must create the dbharbour database with the
zip located in the \sql\dbharbour.sql.zip folder
You must give access to it with:
user:harbour
psw:hb1234

Validates the configuration data in the app.ini file

Compiled with Visual Studio 2022 Developer Command Prompt



Enjoy U-Sql (made with UT  https://carles9000.github.io/ )

Charly Aubia 2023