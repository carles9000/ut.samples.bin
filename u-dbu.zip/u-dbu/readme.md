﻿U-Dbu project
================

First Dbu for Web made with UT 

The new way of programming the web with harbour. Fast, powerful, reliable, robust... and only harbour!

Run the server by starting app.exe and then from a browser put the url localhost



Enjoy U-Dbu  

Charly Aubia